from app.models import Claim, Passage
from app.citations.validator import validate_claim, validate_summary_claims


def test_claim_is_valid_when_passage_exists():
    passages = [Passage(id="S1", text="Study included 30 participants.", section="METHODS")]
    claim = Claim(text="The study included 30 participants.", supported_by=["S1"])
    assert validate_claim(claim, passages).valid is True


def test_claim_is_invalid_when_passage_missing():
    claim = Claim(text="Unsupported claim.", supported_by=["S9"])
    assert validate_claim(claim, []).valid is False


def test_coverage_is_traceability_not_truth():
    passages = [Passage(id="S1", text="Source sentence.", section="RESULTS")]
    claims = [
        Claim(text="Claim A", supported_by=["S1"]),
        Claim(text="Claim B", supported_by=["S2"]),
    ]
    checked, coverage = validate_summary_claims(claims, passages)
    assert coverage == 50.0
    assert sum(c.valid for c in checked) == 1
