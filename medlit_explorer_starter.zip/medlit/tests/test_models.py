from app.models import Claim, Passage, PaperRecord, SummaryResult


def test_passage_id_format():
    passage = Passage(id="S1", text="Treatment was associated with improvement.", section="RESULTS")
    assert passage.id == "S1"


def test_paper_record_defaults():
    paper = PaperRecord(title="Example", source_type="pasted")
    assert paper.authors == []
    assert paper.passages == []


def test_summary_coverage_bounds():
    summary = SummaryResult(
        objective=Claim(text="Objective stated.", supported_by=["S1"]),
        conclusion=Claim(text="Conclusion stated.", supported_by=["S2"]),
    )
    assert summary.coverage == 0.0
    assert summary.source_label == "ABSTRACT-ONLY"
