"""MedLit Explorer — Streamlit entry point."""
from __future__ import annotations

import streamlit as st
from app.models import Passage, PaperRecord

st.set_page_config(page_title="MedLit Explorer", page_icon="📚", layout="wide")
st.title("MedLit Explorer")
st.caption("Evidence-grounded medical abstract summaries · Educational and research aid, not a diagnostic tool")

st.info(
    "Abstract-only mode: summaries are based on the abstract or text supplied. "
    "Missing details are reported as “Not reported in the abstract.”"
)

tab_search, tab_paste, tab_about = st.tabs(["Search PubMed", "Paste an abstract", "About"])

with tab_search:
    st.subheader("Find medical research")
    query = st.text_input("Search PubMed", placeholder="e.g., randomized trial diabetes")
    st.caption("PubMed ingestion is being connected. You can use the paste workflow meanwhile.")
    if st.button("Search", disabled=not query.strip()):
        st.warning("Search integration is the next implementation task. No results have been fabricated.")

with tab_paste:
    st.subheader("Summarize an abstract")
    title = st.text_input("Paper title (optional)")
    abstract = st.text_area("Paste abstract", height=220, placeholder="Paste the abstract text here…")
    if st.button("Prepare abstract", disabled=not abstract.strip()):
        # Temporary deterministic sentence tagging so the ingestion/UI contract can be tested.
        import re
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", abstract.strip()) if s.strip()]
        passages = [Passage(id=f"S{i+1}", text=s, section="UNLABELLED") for i, s in enumerate(sentences)]
        record = PaperRecord(
            title=title.strip() or "Pasted abstract",
            passages=passages,
            source_type="pasted",
        )
        st.session_state["prepared_paper"] = record.model_dump()
        st.success(f"Prepared {len(passages)} source sentence(s). Summarization is not wired yet.")
    if "prepared_paper" in st.session_state:
        paper = st.session_state["prepared_paper"]
        st.markdown("**Source passages**")
        for passage in paper["passages"]:
            st.markdown(f"**[{passage['id']}]** {passage['text']}")

with tab_about:
    st.markdown("""
    **Planned core features**
    - PubMed search and metadata
    - Sentence-tagged source passages
    - Structured summaries with PICO and study-design labels
    - Citation validation and evidence coverage
    - Batch processing and quality evaluation
    - SQLite cache for reliable demos

    Full-text PDF/OCR, accounts, personal libraries, PostgreSQL, deployment, and exports are outside
    the initial scope described in the project plan.
    """)
