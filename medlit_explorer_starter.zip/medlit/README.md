# MedLit Explorer

MedLit Explorer is a Streamlit research aid that retrieves medical abstracts from PubMed or accepts pasted abstracts, then produces structured, source-grounded summaries. The initial scope is **abstract-only** and educational; it is not a diagnostic tool.

## Stack

- Python 3.11
- Streamlit
- Pydantic
- PubMed / NCBI E-utilities
- SQLite cache
- pytest

## Setup

1. Install Python 3.11.
2. Create and activate a virtual environment:

   **Windows PowerShell**
   ```powershell
   py -3.11 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   **macOS/Linux**
   ```bash
   python3.11 -m venv .venv
   source .venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env` and add your own values locally. Do not commit `.env`.
5. Run the app:
   ```bash
   streamlit run streamlit_app.py
   ```

The initial UI scaffold supports pasting an abstract and tagging its sentences. PubMed search and LLM summarization are intentionally marked as not yet connected; do not treat this scaffold as the finished product.

## Team responsibilities

1. **Team lead / AI and prompts:** `app/models.py`, `app/ai/`, `prompts/`, integration and prompt documentation.
2. **Backend / ingestion:** `app/ingestion/`, `app/storage/`, PubMed parsing, sentence tagging, SQLite cache.
3. **Frontend:** `streamlit_app.py`, `app/ui/`, result and batch views.
4. **Citation validation / comparison:** `app/citations/`, `app/comparisons/`, optional grounded chat if core features are stable.
5. **Evaluation / QA / documentation:** `eval/`, `data/`, `docs/`, `tests/`, test set and demo video.

## Shared contracts

All modules should use the Pydantic models in `app/models.py`: `Passage`, `PaperRecord`, `Claim`, `SummaryResult`, and `EvaluationRecord`. Do not create duplicate definitions in feature branches without coordinating with the team lead.

## Git collaboration

- `main` should remain runnable.
- Each person works on a feature branch and opens a pull request.
- Make small, focused commits and pull from `main` before beginning a task.
- Agree on shared model/API changes before implementation.
- Never commit `.env`, API keys, private data, or generated databases.
- Use mock data/stubs when another module is not ready.

Suggested branches:
- `feature/summarizer`
- `feature/ingestion`
- `feature/streamlit-ui`
- `feature/citation-validation`
- `feature/evaluation`

## Quality and evidence rules

- The application generates and validates citation IDs; the LLM must not invent IDs.
- Every cited passage ID must resolve to a real source sentence.
- Preserve uncertainty and qualifiers; do not invent methods, sample sizes, numbers, or limitations.
- If information is absent, say **“Not reported in the abstract.”**
- Label output **ABSTRACT-ONLY**.
- Evidence coverage measures traceability, not factual correctness.
- Report evaluation method and sample size honestly. Do not claim an 85% score unless measured results support it.

## Initial scope

Core: PubMed search, paste-in abstract, sentence passage tagging, structured summary, PICO badges, study-design label, citation validation, evidence coverage, summary length options, batch mode, abstract-only missing-data handling, evaluation.

Later / only if core is stable: 2–3 paper comparison, glossary, explanation levels, grounded chat, evaluation UI, PDF text extraction without OCR.

Explicitly out of scope for this version: authentication, personal libraries, collections, PostgreSQL, migrations, backups, object storage, OCR, deployment, Crossref, citation graph, and exports.

## Existing scripts

The original paper-discovery and literature-review scripts are retained in `scripts/` as adaptation starting points. They are not yet wired into the Streamlit app; please review and adapt them to the shared `PaperRecord` contract before integrating them. Verify all API credentials are supplied through environment variables, never source code.

## Current status

This repository is a scaffold. PubMed search, AI summarization, citation UI interactions, batch processing, and evaluation are still to be implemented.
