import csv
import os
import time
import xml.etree.ElementTree as ET
import requests

# ----------------- CONFIGURATION -----------------
SEMANTIC_SCHOLAR_API_KEY = os.getenv("SEMANTIC_SCHOLAR_API_KEY", "").strip()
PUBMED_API_KEY = os.getenv("PUBMED_API_KEY", "").strip()

TARGET_COUNT = 50
OUTPUT_FILE = "neurosymbolic_healthcare_50_papers.csv"
# -------------------------------------------------

HEALTHCARE_TERMS = {
    "health", "clinical", "medical", "patient", "disease", "diagnosis", 
    "drug", "radiology", "biomedical", "ehr", "hospital", "pathology", "oncology"
}
NEURO_SYMBOLIC_TERMS = {
    "neurosymbolic", "neuro-symbolic", "knowledge graph", "ontology", 
    "symbolic reasoning", "neural-symbolic", "logic tensor"
}

def is_relevant(title: str, abstract: str) -> bool:
    """Checks if the paper connects healthcare with neurosymbolic concepts."""
    text = f"{title} {abstract}".lower()
    has_health = any(k in text for k in HEALTHCARE_TERMS)
    has_ns = any(k in text for k in NEURO_SYMBOLIC_TERMS) or (
        ("neural" in text or "deep learning" in text) and ("logic" in text or "knowledge" in text or "reasoning" in text)
    )
    return has_health and has_ns


def normalize_doi(value):
    """Return a normalized DOI string, or an empty string when unavailable."""
    if not value:
        return ""
    value = str(value).strip()
    if value.lower().startswith("https://doi.org/"):
        value = value[16:]
    elif value.lower().startswith("http://doi.org/"):
        value = value[14:]
    elif value.lower().startswith("doi:"):
        value = value[4:]
    return value.strip()


def make_paper(title="", source="", authors="", publication_date="", year="", citations="",
              doi="", identifier="", pdf_link="", abstract=""):
    """Build one consistent metadata record across all source adapters."""
    doi = normalize_doi(doi)
    return {
        "Title": (title or "").strip(),
        "Authors": authors or "N/A",
        "Source": source or "N/A",
        "Publication_Date": publication_date or "N/A",
        "Year": year or (publication_date[:4] if publication_date and publication_date != "N/A" else "N/A"),
        "Citations": citations if citations not in (None, "") else "N/A",
        "DOI": doi or "N/A",
        "Identifier": identifier or "N/A",
        "PDF_Link": pdf_link or "N/A",
        "Abstract": abstract or "Abstract not provided by API",
    }


def paper_dedupe_keys(paper):
    """Prefer stable identifiers; fall back to normalized title."""
    keys = []
    doi = normalize_doi(paper.get("DOI", ""))
    identifier = str(paper.get("Identifier", "")).strip().lower()
    if doi and doi != "N/A":
        keys.append("doi:" + doi.lower())
    if identifier and identifier != "n/a":
        keys.append("id:" + identifier)
    title = " ".join(str(paper.get("Title", "")).lower().split())
    if title:
        keys.append("title:" + title)
    return keys

# 1. Semantic Scholar Query
def fetch_semantic_scholar(limit_needed: int):
    collected = []
    base_url = "https://api.semanticscholar.org/graph/v1/paper/search"
    headers = {"x-api-key": SEMANTIC_SCHOLAR_API_KEY} if SEMANTIC_SCHOLAR_API_KEY else {}

    # Simplified search terms compatible with Semantic Scholar's engine
    queries = [
        "neurosymbolic clinical",
        "neurosymbolic medical diagnosis",
        "knowledge graph deep learning medicine",
        "neural symbolic healthcare"
    ]

    for q in queries:
        if len(collected) >= limit_needed:
            break
        params = {
            "query": q,
            "limit": 40,
            "fields": "title,abstract,year,publicationDate,authors,citationCount,externalIds,openAccessPdf"
        }
        try:
            res = requests.get(base_url, params=params, headers=headers, timeout=15)
            if res.status_code == 200:
                data = res.json().get("data", [])
                for item in data:
                    title = item.get("title") or ""
                    abstract = item.get("abstract") or ""
                    # If abstract is not indexed, check title relevance
                    if is_relevant(title, abstract):
                        external_ids = item.get("externalIds") or {}
                        pub_date = item.get("publicationDate") or (str(item.get("year")) if item.get("year") else "")
                        authors = "; ".join(a.get("name", "").strip() for a in (item.get("authors") or []) if a.get("name"))
                        collected.append(make_paper(
                            title=title, source="Semantic Scholar", authors=authors,
                            publication_date=pub_date, year=item.get("year"),
                            citations=item.get("citationCount"), doi=external_ids.get("DOI"),
                            identifier=external_ids.get("CorpusId") or external_ids.get("PaperId") or "N/A",
                            pdf_link=(item.get("openAccessPdf") or {}).get("url"), abstract=abstract
                        ))
            else:
                print(f"  [Semantic Scholar Warning] HTTP {res.status_code}: {res.text[:100]}")
            time.sleep(1.1)
        except Exception as e:
            print(f"  [Semantic Scholar Error]: {e}")

    return collected

# 2. PubMed Query
def fetch_pubmed(limit_needed: int):
    collected = []
    base_search = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    base_fetch = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"

    query = '((neurosymbolic OR "neuro-symbolic") OR ("knowledge graph" AND ("deep learning" OR "neural"))) AND (clinical OR medical OR diagnosis OR health)'
    params = {
        "db": "pubmed",
        "term": query,
        "retmode": "json",
        "retmax": 60,
    }
    if PUBMED_API_KEY:
        params["api_key"] = PUBMED_API_KEY

    try:
        res = requests.get(base_search, params=params, timeout=15).json()
        id_list = res.get("esearchresult", {}).get("idlist", [])

        if id_list:
            fetch_params = {
                "db": "pubmed",
                "id": ",".join(id_list),
                "retmode": "xml"
            }
            if PUBMED_API_KEY:
                fetch_params["api_key"] = PUBMED_API_KEY

            xml_resp = requests.get(base_fetch, params=fetch_params, timeout=25)
            root = ET.fromstring(xml_resp.content)

            for article in root.findall(".//PubmedArticle"):
                title_elem = article.find(".//ArticleTitle")
                abstract_elem = article.find(".//AbstractText")
                pmid_elem = article.find(".//PMID")
                title = " ".join("".join(title_elem.itertext()).split()) if title_elem is not None else ""
                abstract = " ".join("".join(abstract_elem.itertext()).split()) if abstract_elem is not None else ""
                pmid = pmid_elem.text.strip() if pmid_elem is not None and pmid_elem.text else "N/A"
                author_names = []
                for author in article.findall(".//AuthorList/Author"):
                    collective = author.findtext("CollectiveName")
                    fore = author.findtext("ForeName") or ""
                    last = author.findtext("LastName") or ""
                    name = collective or " ".join(part for part in (fore, last) if part)
                    if name:
                        author_names.append(name)
                date_elem = article.find(".//ArticleDate")
                if date_elem is not None:
                    y, m, d = date_elem.findtext("Year"), date_elem.findtext("Month"), date_elem.findtext("Day")
                    publication_date = "-".join(x for x in (y, m.zfill(2) if m else None, d.zfill(2) if d else None) if x)
                else:
                    pub_date = article.find(".//JournalIssue/PubDate")
                    y = pub_date.findtext("Year") if pub_date is not None else None
                    if not y and pub_date is not None:
                        medline = pub_date.findtext("MedlineDate") or ""
                        y = medline[:4] if len(medline) >= 4 and medline[:4].isdigit() else None
                    publication_date = y or ""
                doi = ""
                for aid in article.findall(".//PubmedData/ArticleIdList/ArticleId"):
                    if aid.attrib.get("IdType", "").lower() == "doi" and aid.text:
                        doi = aid.text.strip()
                        break
                if is_relevant(title, abstract):
                    collected.append(make_paper(
                        title=title, source="PubMed", authors="; ".join(author_names),
                        publication_date=publication_date, year=publication_date[:4] if publication_date else "",
                        doi=doi, identifier=f"PMID:{pmid}",
                        pdf_link=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/", abstract=abstract
                    ))
    except Exception as e:
        print(f"  [PubMed Error]: {e}")

    return collected

# 3. arXiv Query
def fetch_arxiv(limit_needed: int):
    collected = []
    base_url = "http://export.arxiv.org/api/query"
    queries = [
        'all:"neurosymbolic" AND (all:"medical" OR all:"clinical" OR all:"health")',
        'all:"neuro-symbolic" AND (all:"medical" OR all:"clinical" OR all:"biomedical")'
    ]

    for q in queries:
        if len(collected) >= limit_needed:
            break
        params = {
            "search_query": q,
            "start": 0,
            "max_results": 40,
            "sortBy": "relevance",
            "sortOrder": "descending"
        }
        try:
            res = requests.get(base_url, params=params, timeout=15)
            if res.status_code == 200:
                root = ET.fromstring(res.content)
                for entry in root.findall("{http://www.w3.org/2005/Atom}entry"):
                    title = entry.find("{http://www.w3.org/2005/Atom}title").text.strip().replace("\n", " ")
                    summary = entry.find("{http://www.w3.org/2005/Atom}summary").text.strip().replace("\n", " ")
                    paper_id = entry.find("{http://www.w3.org/2005/Atom}id").text.strip()
                    published = entry.find("{http://www.w3.org/2005/Atom}published").text[:4]

                    authors = "; ".join(
                        (author.find("{http://www.w3.org/2005/Atom}name").text or "").strip()
                        for author in entry.findall("{http://www.w3.org/2005/Atom}author")
                        if author.find("{http://www.w3.org/2005/Atom}name") is not None
                    )
                    published_full = entry.find("{http://www.w3.org/2005/Atom}published").text.strip()
                    if is_relevant(title, summary):
                        collected.append(make_paper(
                            title=title, source="arXiv", authors=authors,
                            publication_date=published_full[:10], year=published,
                            identifier=paper_id, pdf_link=paper_id.replace("abs", "pdf"), abstract=summary
                        ))
            time.sleep(3.0)
        except Exception as e:
            print(f"  [arXiv Error]: {e}")

    return collected

def main():
    all_papers = []
    seen_keys = set()

    def add_unique(papers, limit=None):
        added = 0
        for paper in papers:
            keys = paper_dedupe_keys(paper)
            if any(key in seen_keys for key in keys):
                continue
            all_papers.append(paper)
            seen_keys.update(keys)
            added += 1
            if limit is not None and len(all_papers) >= limit:
                break
        return added

    if not SEMANTIC_SCHOLAR_API_KEY:
        print("[Info] SEMANTIC_SCHOLAR_API_KEY is not set; trying Semantic Scholar without an API key.")
    if not PUBMED_API_KEY:
        print("[Info] PUBMED_API_KEY is not set; PubMed requests will use public access limits.")

    print("Step 1: Querying Semantic Scholar...")
    add_unique(fetch_semantic_scholar(30))
    print(f"-> Total count now: {len(all_papers)}")

    if len(all_papers) < TARGET_COUNT:
        print("Step 2: Querying PubMed...")
        add_unique(fetch_pubmed(40), TARGET_COUNT)
        print(f"-> Total count now: {len(all_papers)}")

    if len(all_papers) < TARGET_COUNT:
        print("Step 3: Querying arXiv to complete the target 50...")
        add_unique(fetch_arxiv(TARGET_COUNT - len(all_papers) + 10), TARGET_COUNT)
        print(f"-> Final count: {len(all_papers)}")

    fieldnames = ["Title", "Authors", "Source", "Publication_Date", "Year", "Citations", "DOI", "Identifier", "PDF_Link", "Abstract"]
    with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_papers[:TARGET_COUNT])

    print(f"\nDone! Successfully saved {min(len(all_papers), TARGET_COUNT)} papers to '{OUTPUT_FILE}'.")


if __name__ == "__main__":
    main()