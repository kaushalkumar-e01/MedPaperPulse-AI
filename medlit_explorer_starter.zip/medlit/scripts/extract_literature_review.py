import os
import re
import time
import logging
import requests
import pandas as pd
from bs4 import BeautifulSoup

INPUT_CSV = "neurosymbolic_healthcare_50_papers.csv"
OUTPUT_EXCEL = "Neurosymbolic_AI_Healthcare_Literature_Review.xlsx"

PUBMED_API_KEY = os.getenv("PUBMED_API_KEY", "").strip()

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

def clean_text(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def summarize_one_liner(text: str, fallback_prefix: str = "") -> str:
    """Extracts a high-impact, single-sentence summary from a text section."""
    if not text or len(text.strip()) < 10:
        return "N/A"
    sentences = re.split(r"(?<=[.!?])\s+", clean_text(text))
    # Pick the most informative sentence
    for s in sentences:
        s_clean = s.strip()
        if len(s_clean) > 40 and not s_clean.lower().startswith("table") and not s_clean.lower().startswith("figure"):
            return s_clean
    return sentences[0][:200]

def fetch_pmc_fulltext_sections(pmid: str):
    """Fetches structured full-text XML from PubMed Central (PMC) if available."""
    sections = {"Methodology": "", "Results": "", "Conclusion": ""}
    if not pmid or pmid == "N/A":
        return sections
    
    # 1. Map PMID to PMCID
    conv_url = f"https://www.ncbi.nlm.nih.gov/pmc/utils/idconv/v1.0/?ids={pmid}&format=json"
    try:
        r = requests.get(conv_url, timeout=10).json()
        records = r.get("records", [])
        if not records or "pmcid" not in records[0]:
            return sections
        pmcid = records[0]["pmcid"]
        
        # 2. Fetch full XML text from PMC E-Fetch
        fetch_url = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&id={pmcid}&retmode=xml"
        if PUBMED_API_KEY:
            fetch_url += f"&api_key={PUBMED_API_KEY}"
            
        xml_resp = requests.get(fetch_url, timeout=20)
        soup = BeautifulSoup(xml_resp.content, "xml")
        
        for sec in soup.find_all("sec"):
            title = sec.find("title")
            title_text = title.text.lower() if title else ""
            p_text = " ".join([p.text for p in sec.find_all("p")])
            
            if any(k in title_text for k in ["method", "approach", "framework", "model", "pipeline"]):
                if not sections["Methodology"]:
                    sections["Methodology"] = p_text
            elif any(k in title_text for k in ["result", "finding", "experiment", "evaluation"]):
                if not sections["Results"]:
                    sections["Results"] = p_text
            elif any(k in title_text for k in ["conclus", "discussion", "future work"]):
                if not sections["Conclusion"]:
                    sections["Conclusion"] = p_text
    except (requests.RequestException, ValueError, KeyError) as e:
        logger.warning("Could not retrieve PMC full text for PMID %s: %s", pmid, e)
    
    return sections

def process_papers():
    if not os.path.exists(INPUT_CSV):
        print(f"Error: Could not find '{INPUT_CSV}'. Please ensure it is in the same directory.")
        return

    df = pd.read_csv(INPUT_CSV)
    structured_rows = []

    print(f"Processing {len(df)} papers from '{INPUT_CSV}'...")

    for idx, row in df.iterrows():
        title = row.get("Title", "Untitled")
        abstract = str(row.get("Abstract", ""))
        doi = str(row.get("DOI", ""))
        identifier = str(row.get("Identifier", ""))
        # Backward compatibility with CSV files created by the previous script version.
        legacy_identifier = str(row.get("DOI/Identifier", ""))
        doi_or_id = identifier if identifier not in ("", "nan", "N/A") else legacy_identifier
        if doi in ("", "nan", "N/A") and legacy_identifier.lower().startswith("10."):
            doi = legacy_identifier
        source = row.get("Source", "")
        authors = row.get("Authors", "N/A")
        publication_date = row.get("Publication_Date", "N/A")
        year = row.get("Year", "N/A")
        citations = row.get("Citations", "N/A")
        pdf_link = row.get("PDF_Link", "")

        # Default fallbacks
        method_text = ""
        result_text = ""
        conclusion_text = ""

        # Query full-text if paper originates from PubMed
        if "PMID:" in doi_or_id:
            pmid = doi_or_id.replace("PMID:", "").strip()
            full_sections = fetch_pmc_fulltext_sections(pmid)
            method_text = full_sections["Methodology"]
            result_text = full_sections["Results"]
            conclusion_text = full_sections["Conclusion"]
            time.sleep(0.3)

        # Fallback to abstract sentence-level extraction if full-text XML is restricted
        if not method_text or not result_text or not conclusion_text:
            sentences = re.split(r"(?<=[.!?])\s+", clean_text(abstract))
            if len(sentences) >= 3:
                method_text = method_text or sentences[1]
                result_text = result_text or sentences[-2]
                conclusion_text = conclusion_text or sentences[-1]
            else:
                method_text = method_text or abstract
                result_text = result_text or abstract
                conclusion_text = conclusion_text or abstract

        # Generate one-line summaries
        abs_summary = summarize_one_liner(abstract)
        method_summary = summarize_one_liner(method_text)
        result_summary = summarize_one_liner(result_text)
        conclusion_summary = summarize_one_liner(conclusion_text)

        structured_rows.append({
            "Paper ID": idx + 1,
            "Title": title,
            "Authors": authors,
            "Publication Date": publication_date,
            "Year": year,
            "Citations": citations,
            "Source": source,
            "DOI": doi if doi not in ("", "nan") else "N/A",
            "Identifier": doi_or_id,
            "Open Access Link": pdf_link,
            "Abstract (1-Line Summary)": abs_summary,
            "Methodology (1-Line Summary)": method_summary,
            "Results (1-Line Summary)": result_summary,
            "Conclusion (1-Line Summary)": conclusion_summary
        })

        print(f"[{idx+1}/{len(df)}] Extracted: {title[:60]}...")

    # Export to Excel with auto-sized columns
    out_df = pd.DataFrame(structured_rows)
    with pd.ExcelWriter(OUTPUT_EXCEL, engine="openpyxl") as writer:
        out_df.to_excel(writer, index=False, sheet_name="Literature Review")
        worksheet = writer.sheets["Literature Review"]
        for col in worksheet.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            col_letter = col[0].column_letter
            worksheet.column_dimensions[col_letter].width = min(max(max_len + 3, 15), 50)

    print(f"\nDone! Literature review table saved to '{OUTPUT_EXCEL}'.")

if __name__ == "__main__":
    process_papers()