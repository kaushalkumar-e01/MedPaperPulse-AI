The two original scripts are retained here as adaptation starting points:
- `get_50_papers.py`
- `extract_literature_review.py`

Before integrating, verify that all secrets are read from environment variables and that outputs map to `app.models.PaperRecord`. These scripts are not yet called by the Streamlit app.
