"""Shared data contracts for MedLit Explorer.

All team members should import these models rather than defining competing schemas.
The app summarizes abstracts only; it must not imply full-text review unless the source
actually contains full text.
"""
from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field, ConfigDict


class Passage(BaseModel):
    """One source sentence, assigned an application-generated stable ID."""
    model_config = ConfigDict(extra="forbid")

    id: str = Field(pattern=r"^S[1-9][0-9]*$")
    text: str = Field(min_length=1)
    section: str = "UNLABELLED"


class PaperRecord(BaseModel):
    """Normalized paper metadata plus sentence-tagged abstract passages."""
    model_config = ConfigDict(extra="forbid")

    pmid: str | None = None
    doi: str | None = None
    title: str
    authors: list[str] = Field(default_factory=list)
    journal: str | None = None
    pub_date: str | None = None
    pub_types: list[str] = Field(default_factory=list)
    url: str | None = None
    passages: list[Passage] = Field(default_factory=list)
    source_type: Literal["abstract", "pasted"] = "abstract"


class Claim(BaseModel):
    """A summary claim tied to one or more source passage IDs."""
    model_config = ConfigDict(extra="forbid")

    text: str = Field(min_length=1)
    supported_by: list[str] = Field(default_factory=list)
    valid: bool = False


class SummaryResult(BaseModel):
    """Structured summary output shared by the AI, UI, and validation modules."""
    model_config = ConfigDict(extra="forbid")

    pmid: str | None = None
    title: str | None = None
    pico: dict[str, str] = Field(default_factory=lambda: {
        "population": "Not reported in the abstract",
        "intervention": "Not reported in the abstract",
        "comparison": "Not reported in the abstract",
        "outcome": "Not reported in the abstract",
    })
    design: str = "Not reported in the abstract"
    objective: Claim
    findings: list[Claim] = Field(default_factory=list)
    conclusion: Claim
    limitations: list[Claim] = Field(default_factory=list)
    glossary: dict[str, str] = Field(default_factory=dict)
    coverage: float = Field(default=0.0, ge=0.0, le=100.0)
    summary_length: Literal["short", "standard", "detailed"] = "standard"
    explanation_level: Literal["beginner", "student", "researcher"] = "student"
    source_label: Literal["ABSTRACT-ONLY"] = "ABSTRACT-ONLY"


class EvaluationRecord(BaseModel):
    """One evaluation observation; scores are recorded, not fabricated."""
    model_config = ConfigDict(extra="forbid")

    case_id: str
    factual_consistency: float | None = Field(default=None, ge=1, le=5)
    completeness: float | None = Field(default=None, ge=1, le=5)
    readability: float | None = Field(default=None, ge=1, le=5)
    evidence_support: float | None = Field(default=None, ge=1, le=5)
    reviewer_notes: str = ""
