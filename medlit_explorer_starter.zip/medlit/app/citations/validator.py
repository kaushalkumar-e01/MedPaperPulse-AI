"""Deterministic citation-ID resolution and traceability coverage."""
from __future__ import annotations
from app.models import Claim, Passage


def validate_claim(claim: Claim, passages: list[Passage]) -> Claim:
    available = {p.id for p in passages}
    claim.valid = bool(claim.supported_by) and all(pid in available for pid in claim.supported_by)
    return claim


def validate_summary_claims(claims: list[Claim], passages: list[Passage]) -> tuple[list[Claim], float]:
    checked = [validate_claim(c, passages) for c in claims]
    coverage = (sum(c.valid for c in checked) / len(checked) * 100.0) if checked else 0.0
    return checked, round(coverage, 2)
