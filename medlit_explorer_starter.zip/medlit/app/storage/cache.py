"""Small SQLite cache keyed by PMID and prompt version."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any


def initialize_cache(db_path: str | Path = "data/medlit_cache.sqlite3") -> None:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS summary_cache (
                pmid TEXT NOT NULL,
                prompt_version TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (pmid, prompt_version)
            )
        """)
        conn.commit()


def get_cached_summary(
    pmid: str, prompt_version: str, db_path: str | Path = "data/medlit_cache.sqlite3"
) -> dict[str, Any] | None:
    initialize_cache(db_path)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT payload_json FROM summary_cache WHERE pmid = ? AND prompt_version = ?",
            (pmid, prompt_version),
        ).fetchone()
    return json.loads(row[0]) if row else None


def put_cached_summary(
    pmid: str, prompt_version: str, payload: dict[str, Any],
    db_path: str | Path = "data/medlit_cache.sqlite3",
) -> None:
    initialize_cache(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """INSERT INTO summary_cache (pmid, prompt_version, payload_json)
               VALUES (?, ?, ?)
               ON CONFLICT(pmid, prompt_version)
               DO UPDATE SET payload_json = excluded.payload_json,
                             created_at = CURRENT_TIMESTAMP""",
            (pmid, prompt_version, json.dumps(payload, ensure_ascii=False)),
        )
        conn.commit()
