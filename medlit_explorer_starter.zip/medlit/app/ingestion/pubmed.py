"""PubMed client starter. Full XML-to-PaperRecord parsing is the ingestion task."""
from __future__ import annotations

import os
import time
from typing import Any
import requests
from dotenv import load_dotenv

load_dotenv()
EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
SESSION = requests.Session()
_LAST_REQUEST = 0.0


class PubMedError(RuntimeError):
    pass


def _throttle() -> None:
    """Keep requests near 3/sec without an API key; be conservative for shared demo use."""
    global _LAST_REQUEST
    min_interval = 0.34 if not os.getenv("NCBI_API_KEY") else 0.12
    elapsed = time.monotonic() - _LAST_REQUEST
    if elapsed < min_interval:
        time.sleep(min_interval - elapsed)
    _LAST_REQUEST = time.monotonic()


def search_pmids(query: str, retmax: int = 10) -> list[str]:
    if not query.strip():
        return []
    _throttle()
    params: dict[str, Any] = {
        "db": "pubmed", "term": query, "retmax": max(1, min(retmax, 100)),
        "retmode": "json", "tool": "medlit-explorer",
    }
    email = os.getenv("NCBI_EMAIL")
    api_key = os.getenv("NCBI_API_KEY")
    if email:
        params["email"] = email
    if api_key:
        params["api_key"] = api_key
    try:
        response = SESSION.get(f"{EUTILS}/esearch.fcgi", params=params, timeout=15)
        response.raise_for_status()
        data = response.json()
        return data.get("esearchresult", {}).get("idlist", [])
    except (requests.RequestException, ValueError) as exc:
        raise PubMedError("PubMed search failed; check network and configuration.") from exc
