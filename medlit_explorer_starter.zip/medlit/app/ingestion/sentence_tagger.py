"""Simple initial sentence tagger; improve abbreviation handling in the ingestion task."""
from __future__ import annotations
import re
from app.models import Passage


SECTION_RE = re.compile(
    r"(?i)\b(background|introduction|objective|objectives|methods?|materials and methods|"
    r"results?|conclusions?|discussion)\s*:\s*"
)


def tag_sentences(text: str) -> list[Passage]:
    """Split abstract text into sentence passages with stable S1... IDs.

    This initial implementation is deliberately conservative and should be tested against
    abbreviations, confidence intervals, p-values, and decimal numbers before production.
    """
    normalized = re.sub(r"\s+", " ", text).strip()
    if not normalized:
        return []
    # Keep a single fallback section until section-aware splitting is enhanced.
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", normalized) if s.strip()]
    return [Passage(id=f"S{i}", text=sentence, section="UNLABELLED")
            for i, sentence in enumerate(sentences, start=1)]
