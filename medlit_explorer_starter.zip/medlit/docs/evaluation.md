# Evaluation plan

Status: planned; no quality score has been measured yet.

Build a fixed test set of 15–20 abstracts: approximately 12–15 real PubMed abstracts spanning study designs and 3–4 synthetic edge cases (missing results, contradictory conclusion, small sample, number-heavy abstract).

Evaluate:
- Factual consistency
- Completeness
- Readability
- Evidence support
- Citation resolution rate (target 95%+)
- Numeric faithfulness (target 95%+)
- Required fields when reported (target 90%+)

Use automated checks, an LLM judge disclosed as such, and manual review of at least 8–10 summaries by two team members. Report the method, sample size, and actual results. Do not claim a target was met until it is measured.
