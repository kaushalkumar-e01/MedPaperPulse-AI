# Prompt versions

Keep versioned prompt files here, e.g. `summary_v1.txt`. Record what changed and why in `docs/approach.md`. Do not place API keys in prompts or commit secrets.
